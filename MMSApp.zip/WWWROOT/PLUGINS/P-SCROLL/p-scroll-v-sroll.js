// ______________ PerfectScrollbar

const ps6 = new PerfectScrollbar('.content.vscroll ', {
	useBothWheelAxes:true,
	suppressScrollX:true,
});

const ps7 = new PerfectScrollbar('.content.vscroll-1 ', {
	useBothWheelAxes:true,
	suppressScrollX:true,
});