// ______________ PerfectScrollbar

const ps3 = new PerfectScrollbar('.notifications-menu', {
	useBothWheelAxes:true,
	suppressScrollX:true,
});

const ps4 = new PerfectScrollbar('.sidebar-left', {
	useBothWheelAxes:true,
	suppressScrollX:true,
});

const ps5 = new PerfectScrollbar('.message-menu', {
	useBothWheelAxes:true,
	suppressScrollX:true,
});