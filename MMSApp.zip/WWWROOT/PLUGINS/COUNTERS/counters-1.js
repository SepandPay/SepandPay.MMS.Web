$( function() {
	$('.counter').countUp();
});