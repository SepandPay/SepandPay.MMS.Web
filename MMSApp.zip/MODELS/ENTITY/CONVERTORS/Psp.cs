﻿using $safeprojectname$.Models.DTO;
namespace $safeprojectname$.Models.Entity
{
    public partial class Psp
    {
        public static implicit operator PSPDto(Psp psp)
        {
            PSPDto dto = new PSPDto
            {
                AcceptorCode = psp.AcceptorCode,
                Alias = psp.Alias,
                CreateDate = psp.CreateDate,
                CreatorUserId = psp.CreatorUserId
            };
            return dto;
        }
        public static implicit operator Psp(PSPDto pspdto)
        {
            Psp psp = new Psp
            {
                AcceptorCode = pspdto.AcceptorCode,
                Alias = pspdto.Alias,
                CreateDate = pspdto.CreateDate,
                CreatorUserId = pspdto.CreatorUserId
            };
            return psp;
        }
        public static implicit operator List<PSPDto>(List<Psp> psps)
        {
            List<PSPDto> list = new();
            foreach (Psp item in psps)
            {
                list.Add(item);
            }
            return list;
        }
    }
}
