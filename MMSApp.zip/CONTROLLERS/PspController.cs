﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using $safeprojectname$.Models.Entity;

namespace $safeprojectname$.Controllers
{
    public class PspController : Controller
    {
        // GET: PspController
        public ActionResult Index()
        {
            List<Psp> lst = new();
            return View(lst);
        }

        // GET: PspController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: PspController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: PspController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: PspController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: PspController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: PspController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: PspController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
