﻿using Microsoft.AspNetCore.Mvc;
using $safeprojectname$.Models;
using System.Diagnostics;
using $safeprojectname$.Models.DTO;
using $safeprojectname$.Models.Entity;

namespace $safeprojectname$.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            Models.DTO.PSPDto dt1 = new Models.DTO.PSPDto();
            Psp p1 = new Psp();
            List<Psp> lst = new();
            List<PSPDto> x = lst;

            dt1 = p1;

            p1 = dt1;
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}